// ENGL 470 — Critical Thinking & Debate: revision content (bilingual EN/AR)
const T = (en, ar) => ({ en, ar });

const lectures = [
  {
    id: 'l1', num: 1,
    title: T('Discussion & Debate', 'المناقشة والمناظرة'),
    tagline: T('Foundations: discussion vs. debate, dialogue rules', 'الأساسيات: المناقشة، المناظرة، وقواعد الحوار'),
    summary: [
      'Discussion: collaborative exchange of ideas; no formal winner.',
      'Debate: formal, structured contest between Pro and Con sides; aims to persuade and reach a conclusion.',
      'Debate skills: logical thinking, self-confidence, communication, time management, creativity.',
      'Dialogue: free conversation; rules include listening, not interrupting, and using "I" statements.',
      'In writing, dialogue can be direct (quoted, with a tag like "she said") or indirect (summarized, no quotes).'
    ],
    terms: [
      { t: T('Discussion', 'مناقشة'), d: T('Talking with others to share ideas/opinions; collaborative, not competitive.', 'الحديث مع الآخرين لتبادل الأفكار والآراء؛ طابعها تعاوني لا تنافسي.') },
      { t: T('Debate', 'مناظرة'), d: T('An organized argument between two opposing sides (Pro/Con) aiming to persuade.', 'جدال منظم بين طرفين متعارضين (مؤيد/معارض) بهدف الإقناع.') },
      { t: T('Dialogue', 'حوار'), d: T('A free conversation between two or more people about a topic.', 'محادثة حرة بين شخصين أو أكثر حول موضوع ما.') },
      { t: T('Direct dialogue', 'حوار مباشر'), d: T('Speech shown in quotation marks with a dialogue tag ("he said").', 'كلام منقول بعلامات تنصيص مع فعل قول مثل "قال".') },
      { t: T('Indirect dialogue', 'حوار غير مباشر'), d: T('A conversation summarized without direct quotations.', 'تلخيص محادثة دون اقتباس مباشر لألفاظها.') },
      { t: T('Dialogue tag', 'فعل القول'), d: T('A phrase like "he said/she asked" attributing a line to its speaker.', 'عبارة مثل "قال/سأل" تُسند الكلام إلى قائله.') }
    ],
    quiz: [
      q('Which is more formal and persuasive?', 'أيّ الخيارات أكثر رسمية وإقناعًا؟', ['Discussion', 'Debate', 'Dialogue', 'Monologue'], ['مناقشة', 'مناظرة', 'حوار', 'مونولوج'], 1),
      q('Debate is competitive in nature; discussion is:', 'المناظرة تنافسية بطبيعتها؛ أما المناقشة فهي:', ['Also competitive', 'Cooperative', 'Aggressive', 'Illegal'], ['تنافسية أيضًا', 'تعاونية', 'عدائية', 'غير مسموحة'], 1),
      q('In a debate, the side that agrees with the topic is called:', 'في المناظرة، يُسمى الطرف الموافق على الموضوع:', ['Con', 'Pro', 'Neutral', 'Judge'], ['المعارض', 'المؤيد', 'الحيادي', 'الحكم'], 1),
      q('A debate typically leads to:', 'تنتهي المناظرة عادة بـ:', ['No conclusion', 'One winner, one loser', 'Mutual understanding only', 'A compromise'], ['بلا نتيجة', 'فوز طرف وخسارة الآخر', 'تفاهم متبادل فقط', 'حل وسط'], 1),
      q('Discussion does NOT aim to:', 'المناقشة لا تهدف إلى:', ['Share information', 'Persuade the audience', 'Exchange ideas', 'Build mutual understanding'], ['تبادل المعلومات', 'إقناع الجمهور', 'تبادل الأفكار', 'بناء تفاهم متبادل'], 1),
      q('Which is NOT a listed skill for debating?', 'أي مما يلي ليست من مهارات المناظرة المذكورة؟', ['Logical thinking', 'Self-confidence', 'Time management', 'Memorizing scripts'], ['التفكير المنطقي', 'الثقة بالنفس', 'إدارة الوقت', 'حفظ نصوص جاهزة'], 3),
      q('A rule for good dialogue is:', 'من قواعد الحوار الجيد:', ['Interrupt to make your point', 'Only one person speaks at a time', 'Generalize others\' views', 'Avoid eye contact'], ['المقاطعة لإثبات رأيك', 'يتحدث شخص واحد فقط في كل مرة', 'التعميم على آراء الآخرين', 'تجنب التواصل البصري'], 1),
      q('"Oh, you can\'t help that," said the Cat — this is:', '"لا يمكنك تجنب ذلك"، قالت القطة — هذا مثال على:', ['Indirect dialogue', 'Direct dialogue', 'A debate rebuttal', 'A loaded question'], ['حوار غير مباشر', 'حوار مباشر', 'رد في مناظرة', 'سؤال محمّل'], 1),
      q('A summary like "He told her the meeting was cancelled" (no quotes) is:', 'جملة مثل "أخبرها أن الاجتماع أُلغي" (دون تنصيص) تُعد:', ['Direct dialogue', 'Indirect dialogue', 'A dialogue tag', 'A debate rebuttal'], ['حوارًا مباشرًا', 'حوارًا غير مباشر', 'فعل قول', 'ردًا في مناظرة'], 1),
      q('A key benefit of discussion & debate is developing:', 'من أهم فوائد المناقشة والمناظرة تطوير:', ['Memorization skills', 'Critical thinking & communication', 'Typing speed', 'Artistic skills'], ['مهارات الحفظ', 'التفكير الناقد والتواصل', 'سرعة الكتابة', 'المهارات الفنية'], 1)
    ]
  },
  {
    id: 'l2', num: 2,
    title: T('Critical Thinking Basics', 'أساسيات التفكير الناقد'),
    tagline: T('Decision-making, the CT process, and its history & value', 'صنع القرار، خطوات التفكير الناقد، وتاريخه وأهميته'),
    summary: [
      'Critical thinking = "thinking about thinking": identifying, analyzing, and fixing flaws in reasoning.',
      'CT steps: identify the problem, gather data, analyze it, identify assumptions, establish significance, decide, communicate.',
      'Good decisions rely on critical thinking to evaluate arguments and overcome egocentrism/sociocentrism.',
      'Rooted in Socrates, Plato, Aristotle; central to flexible thinking, better communication, creativity, and self-reflection.'
    ],
    terms: [
      { t: T('Critical thinking', 'التفكير الناقد'), d: T('Organized, rational thinking to evaluate ideas — "thinking about thinking."', 'تفكير منظم وعقلاني لتقييم الأفكار — "التفكير في التفكير".') },
      { t: T('Decision-making', 'صنع القرار'), d: T('A thoughtful process of choosing among options for acting or thinking.', 'عملية مدروسة لاختيار أحد البدائل للفعل أو التفكير.') },
      { t: T('Argumentation', 'الاحتجاج'), d: T('Reason-giving to justify beliefs, acts, or values.', 'تقديم أسباب لتبرير المعتقدات أو الأفعال أو القيم.') },
      { t: T('Ethics', 'الأخلاق'), d: T('Standards of behavior that guide how we ought to act.', 'معايير سلوكية توجّه كيفية تصرفنا.') },
      { t: T('Teleological ethics', 'الأخلاق الغائية'), d: T('An ethical approach judging actions by their consequences.', 'نهج أخلاقي يحكم على الأفعال بنتائجها.') },
      { t: T('Propaganda', 'الدعاية'), d: T('An organized persuasion campaign to influence a mass audience.', 'حملة إقناع منظمة للتأثير على جمهور واسع.') }
    ],
    quiz: [
      q('Critical thinking is best described as:', 'يوصف التفكير الناقد بأنه:', ['Guessing quickly', 'Thinking about thinking', 'Memorizing facts', 'Avoiding decisions'], ['التخمين السريع', 'التفكير في التفكير', 'حفظ المعلومات', 'تجنب اتخاذ القرارات'], 1),
      q('Which is NOT a step of critical thinking?', 'أي مما يلي ليست خطوة من خطوات التفكير الناقد؟', ['Identify the problem', 'Gather data', 'Ignore assumptions', 'Reach a conclusion'], ['تحديد المشكلة', 'جمع المعطيات', 'تجاهل الافتراضات', 'الوصول إلى نتيجة'], 2),
      q('"Reason-giving to justify beliefs and values" defines:', '"تقديم أسباب لتبرير المعتقدات والقيم" هو تعريف:', ['Propaganda', 'Argumentation', 'Coercion', 'Ethics'], ['الدعاية', 'الاحتجاج', 'الإكراه', 'الأخلاق'], 1),
      q('Teleological ethics judges actions by:', 'تحكم الأخلاق الغائية على الأفعال بناءً على:', ['Rules alone', 'Their consequences', 'Tradition', 'Emotion'], ['القواعد فقط', 'نتائجها', 'التقاليد', 'العاطفة'], 1),
      q('The three influential Greek philosophers mentioned are:', 'الفلاسفة اليونانيون الثلاثة المؤثرون المذكورون هم:', ['Plato, Aristotle, Homer', 'Socrates, Plato, Aristotle', 'Kant, Socrates, Plato', 'Aristotle, Cicero, Plato'], ['أفلاطون، أرسطو، هوميروس', 'سقراط، أفلاطون، أرسطو', 'كانط، سقراط، أفلاطون', 'أرسطو، شيشرون، أفلاطون'], 1),
      q('Critical thinking helps overcome our native:', 'يساعد التفكير الناقد على تجاوز:', ['Curiosity', 'Egocentrism and sociocentrism', 'Vocabulary', 'Memory'], ['حب الاستطلاع', 'التمركز حول الذات والجماعة', 'المفردات', 'الذاكرة'], 1),
      q('A sustained, organized campaign to influence a mass audience is:', 'حملة منظمة ومستمرة للتأثير على جمهور واسع تُسمى:', ['Debate', 'Dialogue', 'Propaganda', 'Ethics'], ['مناظرة', 'حوار', 'دعاية', 'أخلاق'], 2),
      q('Critical thinking is crucial for self-reflection because it helps us:', 'التفكير الناقد ضروري للتفكر الذاتي لأنه يساعدنا على:', ['Avoid all decisions', 'Justify our values and decisions', 'Memorize speeches', 'Win every argument'], ['تجنب كل القرارات', 'تبرير قيمنا وقراراتنا', 'حفظ الخطب', 'الفوز بكل نقاش'], 1),
      q('Coercion is defined as:', 'يُعرَّف الإكراه بأنه:', ['Persuasive communication', 'The threat or use of force', 'A logical fallacy', 'A type of debate'], ['تواصل إقناعي', 'التهديد أو استخدام القوة', 'مغالطة منطقية', 'نوع من المناظرة'], 1),
      q('Critical thinking fosters independence by teaching learners to:', 'يعزز التفكير الناقد الاستقلالية بتعليم المتعلمين:', ['Depend on others\' opinions', 'Think and decide for themselves', 'Avoid mistakes entirely', 'Follow authority blindly'], ['الاعتماد على آراء الآخرين', 'التفكير واتخاذ القرار بأنفسهم', 'تجنب الأخطاء كليًا', 'اتباع السلطة دون تفكير'], 1)
    ]
  },
  {
    id: 'l3', num: 3,
    title: T('Kinds of Reasoning', 'أنواع الاستدلال'),
    tagline: T('Claims, issues, arguments — and deductive vs. inductive reasoning', 'الدعاوى، القضايا، الحجج — والاستدلال الاستنتاجي والاستقرائي'),
    summary: [
      'Claim/statement: something true or false. Issue: a question about a claim\'s truth.',
      'Argument = premise(s) + conclusion; the premise gives a reason for the conclusion.',
      'Deductive argument: "valid" if it\'s impossible for premises to be true and the conclusion false (general → specific).',
      'Inductive argument: premises raise the probability of the conclusion, don\'t prove it (specific → general).',
      'Deductive tests an existing theory; inductive develops a new one.'
    ],
    terms: [
      { t: T('Claim / Statement', 'الدعوى / العبارة'), d: T('Something that can be true or false.', 'قول يمكن أن يكون صادقًا أو كاذبًا.') },
      { t: T('Issue', 'القضية'), d: T('A question about whether a claim is true.', 'سؤال حول صحة دعوى ما.') },
      { t: T('Argument', 'الحجة'), d: T('Premise(s) offered as a reason for a conclusion.', 'مقدمة أو مقدمات تُقدَّم كسبب للوصول إلى نتيجة.') },
      { t: T('Premise', 'المقدمة'), d: T('A claim offered as a reason for another claim.', 'دعوى تُقدَّم كسبب لدعوى أخرى.') },
      { t: T('Conclusion', 'النتيجة'), d: T('The claim a premise is meant to support.', 'الدعوى التي تدعمها المقدمة.') },
      { t: T('Deductive argument', 'الاستدلال الاستنتاجي'), d: T('Valid if it\'s impossible for premises to be true and conclusion false.', 'يكون صحيحًا إذا كان من المستحيل أن تصدق المقدمات وتكذب النتيجة.') },
      { t: T('Inductive argument', 'الاستدلال الاستقرائي'), d: T('Premises make the conclusion probable, not certain.', 'تجعل المقدمات النتيجة محتملة لا مؤكدة.') }
    ],
    reasoningDiagram: {
      deductive: ['All mammals have backbones.', 'Humans are mammals.', 'Therefore, humans have backbones.'],
      inductive: ['This swan is white.', 'That swan is white too.', 'So, probably all swans are white.']
    },
    quiz: [
      q('An issue is best described as:', 'تُعرَّف القضية بأنها:', ['A false claim', 'A question about a claim\'s truth', 'A conclusion', 'A premise'], ['دعوى كاذبة', 'سؤال حول صحة دعوى', 'نتيجة', 'مقدمة'], 1),
      q('In "Sam\'s grandmother died, so he should be excused," the premise is:', 'في "توفيت جدة سام، فينبغي معذرته"، المقدمة هي:', ['Sam should be excused', 'Sam\'s grandmother died', 'Sam missed class', 'None of these'], ['ينبغي معذرة سام', 'توفيت جدة سام', 'غاب سام عن الحصة', 'لا شيء من هذا'], 1),
      q('A deductive argument is "valid" when:', 'تكون الحجة الاستنتاجية "صحيحة" حين:', ['The conclusion is popular', 'Premises true + conclusion false is impossible', 'It uses many examples', 'It\'s about science'], ['تكون النتيجة شائعة', 'يستحيل صدق المقدمات مع كذب النتيجة', 'تستخدم أمثلة كثيرة', 'تتعلق بالعلوم'], 1),
      q('"Josh lives in Alaska, so he lives in the US" is:', '"يعيش جوش في ألاسكا، فهو يعيش في الولايات المتحدة" هذا استدلال:', ['Inductive', 'Deductive', 'A fallacy', 'An issue'], ['استقرائي', 'استنتاجي', 'مغالطة', 'قضية'], 1),
      q('"Fulcher lives in Alaska, so he probably uses mosquito repellent" is:', '"يعيش فولتشر في ألاسكا، فهو يستخدم غالبًا طارد الحشرات" هذا استدلال:', ['Deductive', 'Inductive', 'Invalid', 'Conclusion only'], ['استنتاجي', 'استقرائي', 'غير صحيح', 'نتيجة فقط'], 1),
      q('Inductive reasoning moves from:', 'ينتقل الاستدلال الاستقرائي من:', ['General to specific', 'Specific to general', 'Cause to cause', 'Nowhere'], ['العام إلى الخاص', 'الخاص إلى العام', 'سبب إلى سبب', 'لا اتجاه'], 1),
      q('Deductive reasoning moves from:', 'ينتقل الاستدلال الاستنتاجي من:', ['General to specific', 'Specific to general', 'Random to random', 'Effect to cause'], ['العام إلى الخاص', 'الخاص إلى العام', 'عشوائي إلى عشوائي', 'النتيجة إلى السبب'], 0),
      q('A good inductive argument does what to its conclusion?', 'ماذا تفعل الحجة الاستقرائية الجيدة بنتيجتها؟', ['Proves it', 'Raises its probability', 'Disproves it', 'Ignores it'], ['تبرهنها', 'ترفع احتمال صحتها', 'تنفيها', 'تتجاهلها'], 1),
      q('The claim that supports a conclusion is called the:', 'الدعوى التي تدعم النتيجة تسمى:', ['Issue', 'Premise', 'Debate', 'Rebuttal'], ['القضية', 'المقدمة', 'المناظرة', 'الرد'], 1),
      q('Deductive reasoning is limited because:', 'يكون الاستدلال الاستنتاجي محدودًا لأن:', ['It\'s always false', 'Conclusions are only true if all premises are true', 'It never gives a conclusion', 'It only works with numbers'], ['نتيجته دائمًا كاذبة', 'النتائج تصح فقط إذا صحت كل المقدمات', 'لا يعطي نتيجة أبدًا', 'يعمل فقط مع الأرقام'], 1)
    ]
  },
  {
    id: 'l4', num: 4,
    title: T('Inductive & Deductive Examples', 'أمثلة على الاستقراء والاستنتاج'),
    tagline: T('Worked examples — classify each argument', 'أمثلة محلولة — صنّف كل حجة'),
    summary: [
      'Practice set applying Lecture 3\'s definitions to real statements.',
      'Tip: deductive arguments usually start from a general rule (all/every/always) applied to a specific case.',
      'Tip: inductive arguments usually generalize from limited observations ("some," "last time," "probably").'
    ],
    terms: [
      { t: T('Generalization', 'التعميم'), d: T('A broad claim inferred from specific cases.', 'استنتاج قاعدة عامة من حالات خاصة.') },
      { t: T('Valid argument', 'الحجة الصحيحة منطقيًا'), d: T('A deductive argument where the conclusion must follow from the premises.', 'حجة استنتاجية تلزم فيها النتيجة عن المقدمات.') },
      { t: T('Strong argument', 'الحجة القوية'), d: T('An inductive argument whose premises make the conclusion highly probable.', 'حجة استقرائية تجعل مقدماتها النتيجة شديدة الاحتمال.') }
    ],
    quiz: [
      cq('Some expensive cars are fast. So, all expensive cars are fast.', 0),
      cq('All mammals have backbones. Humans are mammals. Therefore, humans have backbones.', 1),
      cq('Students who missed many classes last semester didn\'t pass. So, students who miss many classes this semester probably won\'t pass.', 0),
      cq('I see fireflies in my backyard every summer. This summer I will probably see fireflies again.', 0),
      cq('All numbers ending in 0 or 5 are divisible by 5. The number 35 ends with 5, so it must be divisible by 5.', 1),
      cq('All birds have feathers. All robins are birds. Therefore, robins have feathers.', 1),
      cq('It\'s dangerous to drive on icy streets. The streets are icy now, so it would be dangerous to drive.', 1),
      cq('Every dog I meet is friendly. So, most dogs are usually friendly.', 0),
      cq('Presidents of the United States are always wealthy. So, Barack Obama must be wealthy.', 1),
      cq('The first two lipsticks I pulled from my bag are red. Therefore, all the lipsticks in my bag are red.', 0)
    ]
  },
  {
    id: 'l5', num: 5,
    title: T('Clear Thinking & Fallacies', 'التفكير الواضح والمغالطات'),
    tagline: T('Fallacies of evidence, reasoning, language, and pseudoarguments', 'مغالطات الدليل، الاستدلال، اللغة، والحجج الزائفة'),
    summary: [
      'A fallacy is an unsound mode of arguing that seems convincing but isn\'t.',
      'Fallacies of evidence: unsupported assertions presented as full arguments.',
      'Fallacies of reasoning: hasty generalization, faulty analogy, causal error, misread sign.',
      'Fallacies of language: ambiguity, verbalism, loaded language.',
      'Fallacies of pseudoargument: irrelevancy, circular reasoning, ignoring the issue, mere repetition.'
    ],
    terms: [
      { t: T('Fallacy', 'المغالطة المنطقية'), d: T('An unsound mode of arguing that appears convincing but isn\'t.', 'طريقة جدل غير سليمة تبدو مقنعة وهي ليست كذلك.') },
      { t: T('Hasty generalization', 'التعميم المتسرع'), d: T('A conclusion drawn from insufficient evidence.', 'استنتاج مبني على أدلة غير كافية.') },
      { t: T('Reasoning by analogy', 'الاستدلال بالتماثل'), d: T('Assuming what\'s true in one case is true in a similar case.', 'افتراض أن ما يصح في حالة يصح في حالة مشابهة.') },
      { t: T('Causal reasoning', 'الاستدلال السببي'), d: T('Identifying the relationship between a cause and its effect.', 'تحديد العلاقة بين السبب ونتيجته.') },
      { t: T('Ambiguity', 'الغموض'), d: T('A word or phrase reasonably interpreted in two or more ways.', 'كلمة أو عبارة تحمل أكثر من معنى معقول.') },
      { t: T('Loaded language', 'اللغة المشحونة'), d: T('Emotionally charged words used to push a conclusion without proof.', 'كلمات مشحونة عاطفيًا تُستخدم لدعم نتيجة دون دليل.') },
      { t: T('Pseudoargument', 'الحجة الزائفة'), d: T('A fake argument built by distortion, confusion, or avoiding the real issue.', 'حجة مصطنعة تعتمد على التحريف أو التهرب من جوهر القضية.') }
    ],
    quiz: [
      q('A fallacy is defined as:', 'تُعرَّف المغالطة بأنها:', ['A true and valid claim', 'An unsound mode of arguing that seems convincing', 'A type of debate', 'A strong premise'], ['دعوى صادقة وصحيحة', 'طريقة جدل غير سليمة تبدو مقنعة', 'نوع من المناظرة', 'مقدمة قوية'], 1),
      q('The four fallacy types are evidence, reasoning, language, and:', 'أنواع المغالطات الأربعة هي: الدليل، الاستدلال، اللغة، و:', ['Ethics', 'Pseudoarguments', 'Propaganda', 'Dialogue'], ['الأخلاق', 'الحجج الزائفة', 'الدعاية', 'الحوار'], 1),
      q('Drawing a broad conclusion from too little evidence is:', 'استنتاج نتيجة عامة من دليل قليل جدًا يسمى:', ['Causal reasoning', 'Hasty generalization', 'Ambiguity', 'Loaded language'], ['استدلال سببي', 'تعميم متسرع', 'غموض', 'لغة مشحونة'], 1),
      q('Assuming what\'s true of one case is true of a similar one is reasoning by:', 'افتراض أن ما يصح في حالة يصح في حالة مشابهة هو استدلال بـ:', ['Sign', 'Cause', 'Analogy', 'Verbalism'], ['الدليل/العلامة', 'السبب', 'التماثل', 'الحشو اللفظي'], 2),
      q('A forecaster predicting rain from low pressure uses:', 'التنبؤ بالمطر من انخفاض الضغط الجوي يستخدم:', ['Analogy', 'Causal reasoning', 'Ambiguity', 'Loaded language'], ['التماثل', 'الاستدلال السببي', 'الغموض', 'اللغة المشحونة'], 1),
      q('A word with two reasonable meanings creates a fallacy of:', 'كلمة تحمل معنيين معقولين تُنشئ مغالطة:', ['Evidence', 'Ambiguity', 'Circular reasoning', 'Sign'], ['الدليل', 'الغموض', 'الدوران', 'العلامة'], 1),
      q('Emotionally charged words pushing a conclusion without proof is:', 'كلمات مشحونة عاطفيًا تدفع نحو نتيجة دون دليل تسمى:', ['Verbalism', 'Loaded language', 'Analogy', 'Sign'], ['الحشو اللفظي', 'اللغة المشحونة', 'التماثل', 'العلامة'], 1),
      q('Using many words without conveying much meaning is:', 'استخدام كلمات كثيرة دون معنى حقيقي يسمى:', ['Verbalism', 'Ambiguity', 'Cause', 'Sign'], ['الحشو اللفظي', 'الغموض', 'السبب', 'العلامة'], 0),
      q('"Arguing in a circle" is a fallacy of:', '"الجدل الدائري" هو مغالطة من نوع:', ['Evidence', 'Reasoning', 'Language', 'Pseudoargument'], ['الدليل', 'الاستدلال', 'اللغة', 'الحجة الزائفة'], 3),
      q('An unsupported assertion presented as a full argument is a fallacy of:', 'تصريح غير مدعوم يُقدَّم كحجة كاملة هو مغالطة:', ['Language', 'Evidence', 'Pseudoargument', 'Reasoning'], ['اللغة', 'الدليل', 'الحجة الزائفة', 'الاستدلال'], 1)
    ]
  },
  {
    id: 'l6', num: 6,
    title: T('Credibility I', 'المصداقية (١)'),
    tagline: T('Claim vs. source credibility, interested parties, phishing', 'مصداقية الدعوى والمصدر، الطرف ذو المصلحة، والتصيد الاحتيالي'),
    summary: [
      'Two arenas of credibility: the claim itself, and its source.',
      'A claim with no initial plausibility is dismissed regardless of source (e.g., "ducks quack in Morse code").',
      'Interested parties (who gain from our belief) deserve more suspicion than disinterested ones.',
      'Irrelevant cues (height, loudness, accent, appearance) are widely but wrongly used to judge credibility.',
      'Phishing exploits false credibility (fake bank sites/emails) to steal personal information.'
    ],
    terms: [
      { t: T('Credibility', 'المصداقية'), d: T('The capability of being believed; the truthfulness of a claim or source.', 'القابلية للتصديق؛ صدق الدعوى أو المصدر.') },
      { t: T('Interested party', 'الطرف ذو المصلحة'), d: T('Someone who stands to gain from our believing a claim.', 'من يستفيد من تصديقنا لدعوى ما.') },
      { t: T('Disinterested party', 'الطرف غير ذي المصلحة'), d: T('Someone with no stake in whether we believe a claim.', 'من لا مصلحة له في تصديقنا للدعوى.') },
      { t: T('Initial plausibility', 'المعقولية المبدئية'), d: T('How believable a claim seems before checking evidence.', 'مدى قابلية الدعوى للتصديق قبل فحص الأدلة.') },
      { t: T('Phishing', 'التصيد الاحتيالي'), d: T('An online scam stealing personal info by impersonating a trusted source.', 'احتيال إلكتروني لسرقة المعلومات الشخصية بانتحال مصدر موثوق.') }
    ],
    quiz: [
      q('The two arenas of credibility are the claim itself and:', 'مجالا المصداقية هما الدعوى نفسها و:', ['The audience', 'The source', 'The argument', 'The debate'], ['الجمهور', 'المصدر', 'الحجة', 'المناظرة'], 1),
      q('A claim like "ducks communicate in Morse code" is dismissed for lacking:', 'دعوى مثل "البط يتواصل بشفرة مورس" تُرفض لأنها تفتقر إلى:', ['Grammar', 'Initial plausibility', 'A source', 'An issue'], ['قواعد لغوية', 'معقولية مبدئية', 'مصدر', 'قضية'], 1),
      q('An interested party should be viewed with:', 'ينبغي التعامل مع الطرف ذي المصلحة بـ:', ['Less suspicion', 'More suspicion', 'No difference', 'Total trust'], ['شك أقل', 'شك أكبر', 'بلا فرق', 'ثقة كاملة'], 1),
      q('Dave (the phishing story) lost money because he:', 'خسر ديف (قصة التصيد) ماله لأنه:', ['Called his bank', 'Entered personal info on a fake site', 'Ignored the email', 'Changed his password'], ['اتصل بالبنك', 'أدخل معلوماته على موقع مزيف', 'تجاهل البريد', 'غيّر كلمة السر'], 1),
      q('Which is an irrelevant factor often mistaken for a credibility clue?', 'أي مما يلي عامل غير ذي صلة يُستخدم خطأً للحكم على المصداقية؟', ['A person\'s expertise', 'A person\'s height/loudness', 'Track record', 'Direct evidence'], ['خبرة الشخص', 'طول الشخص أو صوته العالي', 'سجل الإنجازات', 'دليل مباشر'], 1),
      q('A neighbor\'s denial of robbery loses credibility if:', 'يفقد إنكار الجار للسرقة مصداقيته إذا:', ['He is popular', 'He owns a matching weapon', 'He is disinterested', 'He is an expert'], ['كان محبوبًا', 'كان يملك سلاحًا مطابقًا', 'لم تكن له مصلحة', 'كان خبيرًا'], 1),
      q('Trusting a friend\'s investment tip more because he invested his own money shows:', 'الثقة بنصيحة استثمارية أكثر لأن صاحبها استثمر ماله الخاص تُظهر:', ['Bias', 'Increased credibility from shared risk', 'Decreased credibility', 'Propaganda'], ['تحيّزًا', 'زيادة المصداقية بسبب تحمّله المخاطرة', 'نقص المصداقية', 'دعاية'], 1),
      q('Which factor is NOT reliable for judging credibility?', 'أي عامل غير موثوق للحكم على المصداقية؟', ['Physical appearance', 'Education', 'Experience', 'Track record'], ['المظهر الجسدي', 'التعليم', 'الخبرة', 'سجل الإنجازات'], 0),
      q('A person who profits from our believing a claim is called:', 'من يستفيد من تصديقنا لدعوى ما يُسمى:', ['Disinterested', 'Interested party', 'Expert', 'Skeptic'], ['غير ذي مصلحة', 'طرف ذو مصلحة', 'خبير', 'متشكك'], 1),
      q('Phishing emails often threaten to:', 'كثيرًا ما تهدد رسائل التصيد بـ:', ['Give a refund', 'Suspend/close the account', 'Offer a discount', 'Provide free service'], ['رد الأموال', 'تعليق أو إغلاق الحساب', 'تقديم خصم', 'خدمة مجانية'], 1)
    ]
  },
  {
    id: 'l7', num: 7,
    title: T('Credibility II', 'المصداقية (٢)'),
    tagline: T('Assessing claims: observation, background knowledge, expertise', 'تقييم الدعاوى: الملاحظة، المعرفة الخلفية، والخبرة'),
    summary: [
      'Personal observation is our most reliable source of info — but tiredness, bias, and bad conditions distort it.',
      'Beliefs and expectations shape what we "see" (e.g., expecting a haunted house).',
      'Claims conflicting with strong background information get low initial plausibility.',
      'Broader background knowledge = better ability to evaluate any given report.',
      'Expert claims are reliable only within their area of expertise and when experts agree.'
    ],
    terms: [
      { t: T('Personal observation', 'الملاحظة الشخصية'), d: T('Direct firsthand information — generally reliable, but fallible.', 'معلومة مباشرة من مصدرها، غالبًا موثوقة لكنها قد تُخطئ.') },
      { t: T('Background information', 'المعرفة الخلفية'), d: T('The body of confirmed beliefs we already hold.', 'مجموعة المعتقدات المؤكدة التي نمتلكها مسبقًا.') },
      { t: T('Expertise', 'الخبرة'), d: T('Special knowledge in a subject that boosts a claim\'s credibility.', 'معرفة متخصصة تعزز مصداقية الدعوى.') },
      { t: T('Bias', 'التحيّز'), d: T('A personal interest that distorts perception or judgment.', 'مصلحة شخصية تُشوّه الإدراك أو الحكم.') }
    ],
    quiz: [
      q('Our own observations are:', 'ملاحظاتنا الخاصة هي:', ['Always perfectly accurate', 'Our most reliable but still fallible source', 'Never useful', 'Irrelevant to credibility'], ['دقيقة دائمًا وبشكل مطلق', 'أوثق مصدرنا لكنها قد تُخطئ', 'غير مفيدة أبدًا', 'غير ذات صلة بالمصداقية'], 1),
      q('Moore rejects Parker\'s claim about the car color because it conflicts with his:', 'يرفض مور دعوى باركر عن لون السيارة لأنها تناقض:', ['Background info', 'Personal observation', 'A textbook', 'A friend\'s opinion'], ['معرفته الخلفية', 'ملاحظته الشخصية', 'كتابًا مدرسيًا', 'رأي صديق'], 1),
      q('Factors that can distort observation include:', 'من العوامل التي تُشوّه الملاحظة:', ['Tiredness and bad lighting', 'Perfect eyesight', 'High IQ', 'Careful note-taking'], ['التعب والإضاءة السيئة', 'نظر ممتاز', 'ذكاء مرتفع', 'تدوين ملاحظات دقيق'], 0),
      q('Believing a house is haunted after being told so shows how ___ affect observation.', 'تصديق أن منزلًا مسكون بعد سماع ذلك يوضح تأثير ___ على الملاحظة.', ['Instruments', 'Expectations/beliefs', 'Weather', 'Time of day'], ['الأدوات', 'التوقعات والمعتقدات', 'الطقس', 'وقت اليوم'], 1),
      q('A claim conflicting with well-established background information should get:', 'دعوى تناقض معرفة خلفية راسخة ينبغي أن تُعطى:', ['Immediate acceptance', 'Low initial plausibility', 'Complete disregard', 'Absolute certainty'], ['قبولًا فوريًا', 'معقولية مبدئية منخفضة', 'تجاهلًا كاملًا', 'يقينًا مطلقًا'], 1),
      q('Broader background information helps you:', 'تساعدك المعرفة الخلفية الأوسع على:', ['Avoid all mistakes', 'Evaluate a report effectively', 'Become an interested party', 'Avoid observation'], ['تجنب كل الأخطاء', 'تقييم أي تقرير بفعالية', 'أن تصبح طرفًا ذا مصلحة', 'تجنب الملاحظة'], 1),
      q('Claims by experts are most reliable when they:', 'تكون دعاوى الخبراء أكثر موثوقية عندما:', ['Are outside their expertise', 'Pertain to their area of expertise', 'Contradict other experts', 'Are unsupported'], ['تكون خارج تخصصهم', 'تتعلق بمجال تخصصهم', 'تناقض خبراء آخرين', 'غير مدعومة'], 1),
      q('Doubts about a source fall into two categories: knowledge/expertise and:', 'تنقسم الشكوك حول المصدر إلى فئتين: المعرفة/الخبرة و:', ['Wealth', 'Veracity/objectivity', 'Popularity', 'Age'], ['الثروة', 'الصدق والموضوعية', 'الشعبية', 'العمر'], 1),
      q('Memory affects observation reliability because memory:', 'تؤثر الذاكرة على موثوقية الملاحظة لأن الذاكرة:', ['Is always perfect', 'Can be deceptive', 'Never changes', 'Is irrelevant'], ['دقيقة دائمًا', 'قد تكون مضللة', 'لا تتغير أبدًا', 'غير ذات صلة'], 1),
      q('If we desperately want a project to succeed, we tend to:', 'إذا تمنينا بشدة نجاح مشروع، فإننا نميل إلى:', ['See more evidence of success than exists', 'See only failure', 'Become fully objective', 'Ignore the project'], ['رؤية أدلة نجاح أكثر من الواقع', 'رؤية الفشل فقط', 'أن نصبح موضوعيين تمامًا', 'تجاهل المشروع'], 0)
    ]
  },
  {
    id: 'l8', num: 8,
    title: T('Persuasion Through Rhetoric', 'الإقناع من خلال البلاغة'),
    tagline: T('Slanting devices: euphemism, weaselers, stereotypes, loaded questions...', 'أساليب التحيّز اللغوي: التلطيف، التملّص، القولبة، الأسئلة المُحمَّلة...'),
    summary: [
      'Rhetoric = persuasive language; it shouldn\'t add or subtract logical strength from an argument.',
      'Euphemism (softens) vs. dysphemism (harshens) — e.g., "freedom fighter" vs. "terrorist."',
      'Weaselers ("up to...") hedge a claim; downplayers ("so-called...") minimize importance.',
      'Stereotypes, innuendo, and loaded questions rely on unwarranted assumptions.',
      'Ridicule, hyperbole, proof surrogates, and repetition persuade without real evidence.'
    ],
    terms: [
      { t: T('Rhetoric', 'البلاغة'), d: T('Persuasive use of language to influence beliefs, attitudes, or behavior.', 'استخدام اللغة للتأثير على المعتقدات والمواقف والسلوك.') },
      { t: T('Euphemism', 'التلطيف اللفظي'), d: T('A mild or positive expression replacing a harsher one.', 'تعبير مخفَّف أو إيجابي يحل محل تعبير أقسى.') },
      { t: T('Dysphemism', 'التقبيح اللفظي'), d: T('A harsh or negative expression replacing a neutral one.', 'تعبير سلبي أو قاسٍ يحل محل تعبير محايد.') },
      { t: T('Weaseler', 'كلمة التملّص'), d: T('A word that hedges a claim, giving an escape if it\'s challenged.', 'كلمة تُضعف الدعوى وتفتح بابًا للتراجع عنها.') },
      { t: T('Downplayer', 'التصغير'), d: T('Language that makes something seem less important than it is.', 'لغة تُظهر شيئًا أقل أهمية مما هو عليه.') },
      { t: T('Stereotype', 'القولبة النمطية'), d: T('A generalized assumption about all members of a group.', 'افتراض عام عن كل أفراد جماعة معينة.') },
      { t: T('Loaded question', 'السؤال المُحمَّل'), d: T('A question resting on an unjustified assumption.', 'سؤال يقوم على افتراض غير مبرر.') },
      { t: T('Proof surrogate', 'بديل الدليل'), d: T('A phrase hinting at evidence without ever citing any.', 'عبارة تُلمّح لوجود دليل دون ذكره فعليًا.') }
    ],
    quiz: [
      q('Rhetoric is best described as:', 'تُعرَّف البلاغة بأنها:', ['Formal logic', 'A persuasive-language technique', 'A fallacy of evidence', 'A debate format'], ['منطق صوري', 'أسلوب لغوي إقناعي', 'مغالطة دليل', 'شكل مناظرة'], 1),
      q('"Pre-owned" instead of "used car" is an example of a:', '"مستخدَمة سابقًا" بدل "سيارة مستعملة" مثال على:', ['Dysphemism', 'Euphemism', 'Weaseler', 'Stereotype'], ['تقبيح لفظي', 'تلطيف لفظي', 'كلمة تملّص', 'قولبة نمطية'], 1),
      q('Calling fighters "terrorists" instead of "freedom fighters" is a:', 'تسمية المقاتلين "إرهابيين" بدل "مقاتلي حرية" هو:', ['Euphemism', 'Dysphemism', 'Loaded question', 'Downplayer'], ['تلطيف لفظي', 'تقبيح لفظي', 'سؤال محمّل', 'تصغير'], 1),
      q('"Up to 5 more miles per gallon" is an example of a:', '"حتى 5 أميال إضافية للغالون" مثال على:', ['Weaseler', 'Stereotype', 'Proof surrogate', 'Euphemism'], ['كلمة تملّص', 'قولبة نمطية', 'بديل دليل', 'تلطيف لفظي'], 0),
      q('"He\'s just another liberal" uses a:', '"إنه مجرد ليبرالي آخر" يستخدم:', ['Euphemism', 'Downplayer', 'Loaded question', 'Proof surrogate'], ['تلطيفًا لفظيًا', 'تصغيرًا', 'سؤالًا محمّلًا', 'بديل دليل'], 1),
      q('"Have you stopped cheating on exams?" is a classic:', '"هل توقفت عن الغش في الامتحانات؟" مثال كلاسيكي على:', ['Weaseler', 'Loaded question', 'Euphemism', 'Repetition'], ['كلمة تملّص', 'سؤال محمّل', 'تلطيف لفظي', 'تكرار'], 1),
      q('"Informed sources say..." without naming them is a:', '"تقول مصادر مطّلعة..." دون تسميتها هو:', ['Proof surrogate', 'Stereotype', 'Downplayer', 'Hyperbole'], ['بديل دليل', 'قولبة نمطية', 'تصغير', 'مبالغة'], 0),
      q('"I am so hungry I could eat all the food here" is:', '"أنا جائع جدًا لدرجة أنني قد آكل كل الطعام هنا" مثال على:', ['Innuendo', 'Hyperbole', 'Euphemism', 'Sign'], ['تلميح', 'مبالغة', 'تلطيف لفظي', 'علامة'], 1),
      q('Assuming all members of a group share a trait is a:', 'افتراض أن كل أفراد جماعة يتشاركون صفة واحدة هو:', ['Weaseler', 'Stereotype', 'Proof surrogate', 'Euphemism'], ['كلمة تملّص', 'قولبة نمطية', 'بديل دليل', 'تلطيف لفظي'], 1),
      q('According to the lecture, rhetoric should never be used to:', 'وفق المحاضرة، لا ينبغي استخدام البلاغة أبدًا لـ:', ['Make writing more vivid', 'Add logical points to weak arguments', 'Persuade an audience', 'Choose better words'], ['جعل الكتابة أكثر حيوية', 'إضافة قوة منطقية لحجج ضعيفة', 'إقناع الجمهور', 'اختيار كلمات أفضل'], 1)
    ]
  },
  {
    id: 'l9', num: 9,
    title: T('Argumentative Writing', 'الكتابة الجدلية'),
    tagline: T('Structure, hints, and pitfalls of the argumentative essay', 'بنية المقال الجدلي، نصائحه، وأخطاؤه الشائعة'),
    summary: [
      'Four components: statement of the issue, your position, supporting arguments, rebuttals.',
      'State the issue fairly; keep your position clear and arguments succinct but well-supported.',
      'Four hints: focus, stick to the issue, sequence logically, be complete.',
      'Avoid: the windy preamble, the stream-of-consciousness ramble, the knee-jerk reaction, the glancing blow, "let the reader do the work."',
      'Write for a diverse audience — avoid language that reinforces biased assumptions about groups.'
    ],
    terms: [
      { t: T('Argumentative essay', 'المقال الجدلي'), d: T('Writing that takes a stance on an issue and persuades the reader.', 'كتابة تتبنى موقفًا من قضية وتحاول إقناع القارئ.') },
      { t: T('Rebuttal', 'الرد/التفنيد'), d: T('A response that counters opposing arguments.', 'الرد الذي يفنّد حجج الطرف المعارض.') },
      { t: T('Windy preamble', 'المقدمة المطوّلة'), d: T('An essay flaw: a long, unnecessary introduction before the issue.', 'عيب في المقال: مقدمة طويلة غير ضرورية قبل الوصول للقضية.') },
      { t: T('Stream-of-consciousness ramble', 'السرد العشوائي'), d: T('Unorganized writing with no clear structure.', 'كتابة غير منظمة تفتقر للترتيب الواضح.') },
      { t: T('Glancing blow', 'التطرق السطحي'), d: T('Addressing the topic only obliquely, avoiding the real question.', 'تناول الموضوع بشكل غير مباشر وتجنب السؤال الحقيقي.') }
    ],
    quiz: [
      q('The four components of an argumentative essay include the issue, your position, arguments, and:', 'من مكونات المقال الجدلي الأربعة: القضية، موقفك، الحجج، و:', ['A summary', 'Rebuttals of opposing arguments', 'A bibliography', 'A conclusion only'], ['ملخص', 'تفنيد الحجج المعارضة', 'قائمة مراجع', 'خاتمة فقط'], 1),
      q('A good statement of the issue should be:', 'ينبغي أن يكون عرض القضية:', ['Biased toward your view', 'Fair and neutral', 'As long as possible', 'Left out entirely'], ['منحازًا لرأيك', 'عادلًا ومحايدًا', 'طويلًا بقدر الإمكان', 'محذوفًا تمامًا'], 1),
      q('"Stick to the issue" means every point should:', '"التمسك بالقضية" يعني أن كل نقطة ينبغي أن:', ['Introduce a new topic', 'Support your position or answer objections', 'Be a personal story', 'Repeat the introduction'], ['تقدم موضوعًا جديدًا', 'تدعم موقفك أو ترد على الاعتراضات', 'تكون قصة شخصية', 'تكرر المقدمة'], 1),
      q('An essay that jumps around with no structure is the:', 'المقال الذي يتنقل بلا ترتيب واضح يسمى:', ['Windy preamble', 'Stream-of-consciousness ramble', 'Glancing blow', 'Knee-jerk reaction'], ['المقدمة المطوّلة', 'السرد العشوائي', 'التطرق السطحي', 'رد فعل متسرع'], 1),
      q('Writing your first unconsidered reaction to an issue is the:', 'كتابة أول رد فعل غير متأنٍ حول قضية هو:', ['Knee-jerk reaction', 'Glancing blow', 'Windy preamble', 'Let-the-reader-do-the-work'], ['رد فعل متسرع', 'تطرق سطحي', 'مقدمة مطوّلة', 'ترك القارئ يعمل'], 0),
      q('Addressing a topic only indirectly (e.g. history instead of benefits) is the:', 'تناول الموضوع بشكل غير مباشر (مثل التاريخ بدل الفوائد) هو:', ['Windy preamble', 'Glancing blow', 'Rebuttal', 'Rambling'], ['المقدمة المطوّلة', 'التطرق السطحي', 'الرد', 'السرد العشوائي'], 1),
      q('"Let the reader do the work" essays force readers to follow:', 'مقالات "ترك القارئ يعمل" تُجبر القارئ على متابعة:', ['Clear transitions', 'Non sequiturs and abrupt shifts', 'A neat outline', 'A single idea'], ['انتقالات واضحة', 'استنتاجات غير منطقية وتحولات مفاجئة', 'مخططًا منظمًا', 'فكرة واحدة'], 1),
      q('A good writing practice recommended is to:', 'من ممارسات الكتابة الجيدة الموصى بها:', ['Write only one draft', 'Revise across many drafts', 'Avoid feedback', 'Skip planning'], ['كتابة مسودة واحدة فقط', 'التنقيح عبر مسودات كثيرة', 'تجنب الملاحظات', 'تجاهل التخطيط'], 1),
      q('The more limited your topic, the easier it is to be:', 'كلما كان موضوعك أكثر تحديدًا، كان أسهل أن تكون:', ['Vague', 'Complete', 'Biased', 'Windy'], ['غامضًا', 'شاملًا/كاملًا', 'متحيزًا', 'مطوّلًا'], 1),
      q('Writing in a diverse society means avoiding language that reinforces:', 'الكتابة في مجتمع متنوع تعني تجنب لغة تعزز:', ['Clear logic', 'Questionable assumptions about groups', 'Strong arguments', 'Structure'], ['المنطق الواضح', 'افتراضات مشكوك فيها عن الجماعات', 'حججًا قوية', 'البنية'], 1)
    ]
  }
];

// Inductive vs Deductive Challenge — standalone bank (from "Inductive and Deductive Examples")
const classifyBank = [
  cq('All the swans I\'ve seen are white; therefore, all swans are white.', 0),
  cq('All men are mortal. Socrates is a man. Therefore, Socrates is mortal.', 1),
  cq('Several friends got a raise at their company; therefore, everyone at that company gets a raise.', 0),
  cq('All birds have feathers. A sparrow is a bird. Therefore, a sparrow has feathers.', 1),
  cq('I\'ve only met nice people in that city; therefore, everyone in that city is nice.', 0),
  cq('If it rains, the grass will be wet. It is raining. Therefore, the grass is wet.', 1),
  cq('The last few winters have been extremely cold; therefore, next winter will be cold.', 0),
  cq('Every cat I\'ve owned has been friendly; therefore, all cats are friendly.', 0),
  cq('All squares are rectangles. A given shape is a square. Therefore, it is a rectangle.', 1),
  cq('All humans need oxygen to survive. Maria is a human. Therefore, Maria needs oxygen to survive.', 1),
  cq('Every time I eat strawberries, my throat itches; therefore, I\'m allergic to strawberries.', 0),
  cq('No reptiles have fur. A snake is a reptile. Therefore, a snake does not have fur.', 1),
  cq('All roses are flowers. This is a rose. Therefore, this is a flower.', 1),
  cq('All mammals have backbones. A dolphin is a mammal. Therefore, a dolphin has a backbone.', 1),
  cq('Students who study in groups tend to get better grades; therefore, group study improves grades.', 0)
];

// Fallacy Detective — classify the example into one of the 4 fallacy categories
const fallacyCats = [T('Evidence', 'الدليل'), T('Reasoning', 'الاستدلال'), T('Language', 'اللغة'), T('Pseudoargument', 'الحجة الزائفة')];
function fq(en, ar, catIndex) {
  // Illustrative examples stay in English in both languages, per course-depth setting.
  return { prompt: T(en, en), options: fallacyCats, answer: catIndex };
}
const fallacyBank = [
  fq('A theater review quoted only the positive fragments ("brilliantly executed... lavish costuming") while omitting the critic\'s overall negative verdict.', 'اقتباس إعلان مسرحي لعبارات إيجابية فقط من نقد سلبي في جوهره، مثل "أداء رائع... ملابس فاخرة".', 0),
  fq('"With the death of communism, Russia is now completely democratic — we even have competing candidates," ignoring the deep differences with established democracies.', '"بانهيار الشيوعية، أصبحت روسيا ديمقراطية تمامًا — حتى لدينا مرشحون متنافسون"، متجاهلين الفروق الجوهرية مع الديمقراطيات الراسخة.', 1),
  fq('The weather service predicts rain tomorrow because it detects a low-pressure system today.', 'تتنبأ هيئة الأرصاد بالمطر غدًا بسبب رصدها منطقة ضغط منخفض اليوم.', 1),
  fq('A neurologist checks for the Babinski reflex as a sign of a nervous-system disorder.', 'يفحص طبيب الأعصاب منعكس بابنسكي كعلامة على اضطراب في الجهاز العصبي.', 1),
  fq('A word in a contract can reasonably be read two different ways, and each side insists on its own reading.', 'يمكن قراءة كلمة في عقد بطريقتين معقولتين، ويتمسك كل طرف بقراءته الخاصة.', 2),
  fq('A speech uses many flowery words and phrases but, on close inspection, says almost nothing concrete.', 'يستخدم خطاب كلمات وعبارات منمقة كثيرة لكنه لا يقول شيئًا محددًا عند التدقيق.', 2),
  fq('An ad describes a rival product using harsh, emotionally charged words to make it sound dangerous, without offering evidence.', 'يصف إعلان منتجًا منافسًا بكلمات قاسية ومشحونة عاطفيًا ليبدو خطيرًا، دون تقديم أي دليل.', 2),
  fq('When asked about the budget, a politician talks at length about an unrelated scandal instead.', 'عندما يُسأل سياسي عن الموازنة، يتحدث بدلًا من ذلك وبإطالة عن فضيحة لا صلة لها بالسؤال.', 3),
  fq('"This law is good because it is good for the country, and it\'s good for the country because it is a good law."', '"هذا القانون جيد لأنه مفيد للوطن، وهو مفيد للوطن لأنه قانون جيد" — حجة تدور حول نفسها.', 3),
  fq('A politician simply repeats "I kept every promise" over and over instead of showing evidence.', 'يكرر سياسي عبارة "لقد نفذت كل وعودي" مرارًا دون تقديم أي دليل يثبت ذلك.', 3),
  fq('Someone answers a question about ethics by only restating their conclusion without ever backing it up.', 'يرد شخص على سؤال أخلاقي بإعادة صياغة استنتاجه فقط دون أي دعم فعلي له.', 3),
  fq('After meeting three rude drivers from one city, a traveler concludes everyone from that city is rude.', 'بعد مقابلة ثلاثة سائقين وقحين من مدينة واحدة، يستنتج مسافر أن كل أهل تلك المدينة وقحون.', 1)
];

// Rhetoric Match — timed matching game (device <-> example)
const rhetoricDevices = [
  { device: T('Euphemism', 'التلطيف اللفظي'), example: 'The company called the layoffs a "workforce optimization."' },
  { device: T('Dysphemism', 'التقبيح اللفظي'), example: 'They called the peaceful protesters an unruly "mob."' },
  { device: T('Weaseler', 'كلمة التملّص'), example: 'This cream can remove up to 90% of wrinkles.' },
  { device: T('Downplayer', 'التصغير'), example: 'He\'s just another so-called expert.' },
  { device: T('Stereotype', 'القولبة النمطية'), example: 'Of course she\'s bad at math — she\'s a cheerleader.' },
  { device: T('Innuendo', 'التلميح'), example: 'I\'m not saying he stole it, but it did vanish right after his visit.' },
  { device: T('Loaded Question', 'السؤال المُحمَّل'), example: 'Have you finally stopped lying to your parents?' },
  { device: T('Ridicule / Sarcasm', 'السخرية'), example: 'Oh sure, because THAT plan worked so well last time.' },
  { device: T('Hyperbole', 'المبالغة'), example: 'I\'ve told you a million times to clean your room.' },
  { device: T('Proof Surrogate', 'بديل الدليل'), example: 'Studies show this is true. (No study is ever named.)' },
  { device: T('Repetition', 'التكرار'), example: 'This candidate is the best. Simply the best. Everyone agrees — the best.' }
];

const project1 = {
  title: T('Project 1 — Kidfluencers', 'المشروع الأول — المؤثرون الصغار'),
  intro: [
    'A social media influencer uses platforms to promote brands/products to a captive audience.',
    'Brands like Walmart, Staples, and Mattel now sign endorsement deals with toddlers and tweens — "kidfluencers."',
    'Example: "Samia" had 143,000 Instagram followers and 203,000 YouTube subscribers by age 4, featuring paid promotions.'
  ],
  prosCons: {
    pros: T('Unique family experiences, skill-building, financial benefits.', 'تجارب أسرية فريدة، بناء مهارات، ومنافع مالية.'),
    cons: T('Child exploitation, loss of privacy, harmful content, psychological pressure, disrupted childhood.', 'استغلال الطفل، فقدان الخصوصية، محتوى ضار، ضغط نفسي، واضطراب الطفولة الطبيعية.')
  },
  prompts: [
    T('Should children be social media influencers? Why or why not?', 'هل ينبغي أن يكون الأطفال مؤثرين على وسائل التواصل الاجتماعي؟ لماذا أو لماذا لا؟'),
    T('What age is or isn\'t appropriate for a child to become an influencer?', 'ما العمر المناسب — أو غير المناسب — لكي يصبح الطفل مؤثرًا؟'),
    T('Would you want to be a paid influencer yourself? Why or why not?', 'هل ترغب في أن تكون مؤثرًا مدفوع الأجر؟ لماذا أو لماذا لا؟'),
    T('Should parents allow their children to be "kidfluencers"?', 'هل ينبغي أن يسمح الآباء لأطفالهم بأن يكونوا "مؤثرين صغارًا"؟'),
    T('Do you follow any influencers? Do they promote products on their feed?', 'هل تتابع أي مؤثرين؟ وهل يروّجون لمنتجات على صفحاتهم؟')
  ]
};

function q(en, ar, optsEn, optsAr, answer) {
  return { prompt: T(en, ar), options: optsEn.map((e, i) => T(e, optsAr[i])), answer };
}
function cq(statement, answer) {
  // answer: 0 = Inductive, 1 = Deductive
  return { prompt: T(statement, statement), options: [T('Inductive', 'استقرائي'), T('Deductive', 'استنتاجي')], answer, isClassify: true };
}

const i18n = {
  appTitle: T('Critical Thinking & Debate', 'التفكير الناقد والمناظرة'),
  appSubtitle: T('ENGL 470 — Revision Hub', 'مركز المراجعة — ENGL 470'),
  home: T('Home', 'الرئيسية'),
  lectures: T('Lectures', 'المحاضرات'),
  practice: T('Practice', 'تمارين'),
  lecture: T('Lecture', 'محاضرة'),
  study: T('Study', 'ملخص'),
  keyTerms: T('Key Terms', 'المصطلحات الأساسية'),
  takeQuiz: T('Take Quiz', 'ابدأ الاختبار'),
  flashcards: T('Flashcards', 'البطاقات التعليمية'),
  bestScore: T('Best', 'الأفضل'),
  start: T('Start', 'بدء'),
  next: T('Next', 'التالي'),
  finish: T('Finish', 'إنهاء'),
  yourScore: T('Your score', 'نتيجتك'),
  retry: T('Try Again', 'حاول مرة أخرى'),
  backHome: T('Back to Home', 'العودة للرئيسية'),
  flip: T('Tap to flip', 'اضغط لقلب البطاقة'),
  knowIt: T('I knew it', 'عرفتها'),
  dontKnow: T('Still learning', 'لم أتعلمها بعد'),
  correct: T('Correct!', 'إجابة صحيحة!'),
  incorrect: T('Not quite', 'إجابة غير صحيحة'),
  question: T('Question', 'سؤال'),
  of: T('of', 'من'),
  fallacyDetective: T('Fallacy Detective', 'كاشف المغالطات'),
  idChallenge: T('Inductive vs Deductive', 'الاستقراء والاستنتاج'),
  rhetoricMatch: T('Rhetoric Match', 'مطابقة الأساليب البلاغية'),
  projectDiscussion: T('Project 1: Kidfluencers', 'المشروع 1: المؤثرون الصغار'),
  timeLeft: T('Time left', 'الوقت المتبقي'),
  matches: T('Matches', 'التطابقات'),
  playAgain: T('Play Again', 'العب مرة أخرى'),
  theme: T('Theme', 'المظهر'),
  summary: T('Summary', 'ملخص'),
  discussionPrompts: T('Discussion Prompts', 'أسئلة للنقاش'),
  prosAndCons: T('Pros & Cons', 'الإيجابيات والسلبيات'),
  pros: T('Pros', 'الإيجابيات'),
  cons: T('Cons', 'السلبيات'),
  selectLecture: T('Choose a lecture to review', 'اختر محاضرة للمراجعة'),
  allLectures: T('All Lectures', 'كل المحاضرات'),
  quizzes: T('Quizzes', 'الاختبارات'),
  games: T('Games & Challenges', 'تمارين وتحديات'),
  noScoreYet: T('Not attempted', 'لم يُحل بعد'),
  cardOf: T('Card', 'بطاقة'),
  deckDone: T('Deck complete!', 'اكتملت البطاقات!'),
  shuffle: T('Shuffle', 'إعادة ترتيب'),
  finalScore: T('Final Score', 'النتيجة النهائية'),
  seconds: T('s', 'ث'),
  classifyPrompt: T('Classify this statement:', 'صنّف هذه العبارة:'),
  visualExample: T('Visual Example', 'مثال بصري'),
  deductiveLabel: T('Deductive — general → specific', 'استنتاجي — من العام إلى الخاص'),
  inductiveLabel: T('Inductive — specific → general', 'استقرائي — من الخاص إلى العام'),
  fallacyPrompt: T('Which fallacy type is this?', 'أي نوع من المغالطات هذا؟'),
  home1: T('Progress', 'التقدم'),
  langLabel: T('EN', 'ع'),
};

export default { lectures, classifyBank, fallacyBank, rhetoricDevices, project1, i18n };
